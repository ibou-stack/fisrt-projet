package com.example.projetfinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SecondActivity2 extends AppCompatActivity {
    private Button buttontestcovid;
    private Button resultat;


    @Override
     protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second2);

        this.buttontestcovid=(Button) findViewById(R.id.buttontestcovid);
        this.resultat=(Button) findViewById(R.id.resultat);


        buttontestcovid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i= new Intent(getApplicationContext(),Test_covid.class);
                startActivity(i);
                finish();
                Intent l = new Intent(getApplicationContext(),Resultat.class);
                startActivity(l);
                finish();

            }

        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.p_menu,menu);
        return true;
    }

    @Override
   public boolean onOptionsItemSelected(@NonNull MenuItem item) {
       switch(item.getItemId()){
            case R.id.apropos:
               Toast.makeText(this, "apropos menu selected",Toast.LENGTH_SHORT).show();
               return true;
            case R.id.contact:
                Toast.makeText(this, "contact menu selected",Toast.LENGTH_SHORT).show();
               return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}

