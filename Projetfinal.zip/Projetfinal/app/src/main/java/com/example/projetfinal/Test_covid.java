package com.example.projetfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class Test_covid extends AppCompatActivity {
    private TextView textView19, textView20,textView21,textView22,textView23,textView24,textView25,textView26,textView27;
    private RadioButton R1_yes,R1_no,R2_yes,R2_no, R3_yes,R3_no, R4_yes,R4_no, R5_yes,R5_no, R6_yes,R6_no, R7_yes,R7_no;
    private  Button button2;
     int score=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_covid);

        textView19=(TextView)findViewById(R.id.textView19);
        textView20=(TextView)findViewById(R.id.textView20);
        textView21=(TextView)findViewById(R.id.textView21);
        textView20=(TextView)findViewById(R.id.textView22);
        textView20=(TextView)findViewById(R.id.textView23);
        textView20=(TextView)findViewById(R.id.textView24);
        textView20=(TextView)findViewById(R.id.textView25);
        textView20=(TextView)findViewById(R.id.textView26);

        R1_yes=(RadioButton)findViewById(R.id.R1_yes);
        R1_no=(RadioButton)findViewById(R.id.R1_no);
        R2_yes=(RadioButton)findViewById(R.id.R2_yes);
        R2_no=(RadioButton)findViewById(R.id.R1_no);
        R3_yes=(RadioButton)findViewById(R.id.R3_yes);
        R3_no=(RadioButton)findViewById(R.id.R1_no);
        R4_yes=(RadioButton)findViewById(R.id.R4_yes);
        R4_no=(RadioButton)findViewById(R.id.R4_no);
        R5_yes=(RadioButton)findViewById(R.id.R4_yes);
        R5_no=(RadioButton)findViewById(R.id.R4_no);
        R6_yes=(RadioButton)findViewById(R.id.R6_yes);
        R6_no=(RadioButton)findViewById(R.id.R6_no);
        R7_yes=(RadioButton)findViewById(R.id.R7_yes);
        R7_no=(RadioButton)findViewById(R.id.R7_no);

        button2=(Button)findViewById(R.id.button2);

                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if ( R1_yes.isChecked()){
                            score = score + 1;
                        }else if (R1_no.isChecked()){
                            score = score + 0;
                        }

                        if (R2_yes.isChecked()) {
                            score = score + 1;
                        } else if(R2_no.isChecked()){
                            score = score + 0;
                        }

                        if (R3_yes.isChecked()) {
                            score = score + 1;
                        } else if(R3_no.isChecked()){
                            score = score + 0;
                        }

                        if (R4_yes.isChecked()) {
                            score = score + 1;
                        } else if(R4_no.isChecked()){
                            score = score + 0;
                        }

                        if (R5_yes.isChecked()) {
                            score = score + 1;
                        } else if(R5_no.isChecked()){
                            score = score + 0;
                        }

                        if (R6_yes.isChecked()) {
                            score = score + 1;
                        } else if(R6_yes.isChecked()){
                            score = score + 0;
                        }

                        if (R7_yes.isChecked()) {
                            score = score + 1;
                        } else if(R7_no.isChecked()) {
                            score = score + 0;
                        }

                        Intent i = new Intent(getApplicationContext(), ResultatFinal.class);
                        i.putExtra("scor",score);
                        startActivity(i);


                    }
                });

    }

    public int getScore() {
        return score;
    }
}
