package com.example.projetfinal;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng dakar= new LatLng(33.586685,-7.632254);
        mMap.addMarker(new MarkerOptions().position(dakar).title("marker in dakar"));

        mMap.moveCamera(CameraUpdateFactory.newLatLng(dakar));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(dakar,10));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(dakar,10));

        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            final GoogleMap gmap=mMap;
            @Override
            public void onMapClick(LatLng latLng) {
                gmap.addMarker(new MarkerOptions().position(latLng));
                Toast.makeText(MapsActivity.this,latLng.latitude+"-"+latLng.longitude,Toast.LENGTH_SHORT).show();
            }

        });
        CircleOptions circleOptions=new CircleOptions();
        circleOptions.center(dakar);
        circleOptions.radius(700);
        circleOptions.fillColor((android.R.color.transparent));
        circleOptions.strokeWidth(6);
        mMap.addCircle(circleOptions);


    }



    }


