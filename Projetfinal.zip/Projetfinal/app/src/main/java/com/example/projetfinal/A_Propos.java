package com.example.projetfinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class A_Propos extends AppCompatActivity {
    private TextView nom;
     private TextView prenom;
    private TextView adresse;
    private TextView email;
     private TextView telephone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a__propos);
        this.nom=(TextView)findViewById(R.id.nom);
         this.prenom=(TextView)findViewById(R.id.prenom);
        this.adresse=(TextView)findViewById(R.id.adresse);
        this.email=(TextView)findViewById(R.id.email);
        this.telephone=(TextView)findViewById(R.id.telephone);
        }


}
