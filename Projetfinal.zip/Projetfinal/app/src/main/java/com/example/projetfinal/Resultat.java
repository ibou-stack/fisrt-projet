package com.example.projetfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Resultat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultat);
    }
}